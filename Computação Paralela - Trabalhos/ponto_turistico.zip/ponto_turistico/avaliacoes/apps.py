from django.apps import AppConfig


class AvaliacoesConfig(AppConfig):
    name = 'avaliacoes'
