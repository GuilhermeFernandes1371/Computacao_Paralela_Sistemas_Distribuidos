from django.db import models

# Create your models here.

class Atracao(models.Model):
    nome = models.CharField(verbose_name='Nome', max_length=150)
    descricao = models.TextField(verbose_name='Descrição')
    horario_func = models.TextField(verbose_name='Horário de Funcionamento')
    idade_minima = models.IntegerField(verbose_name='Idade Mínima')
    foto = models.ImageField(upload_to='atracoes', null=True, blank=True)

    def __str__(self):
        return self.nome
