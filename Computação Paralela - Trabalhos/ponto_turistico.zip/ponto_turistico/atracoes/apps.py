from django.apps import AppConfig


class AtracoesConfig(AppConfig):
    name = 'atracoes'
