from django.contrib import admin
from .models import Atracao

# Register your models here.

admin.site.register(Atracao)