from django.db import models
from atracoes.models import Atracao
from comentarios.models import Comentario
from avaliacoes.models import Avaliacao
from enderecos.models import Endereco

# Create your models here.

class PontoTuristico(models.Model):
    nome = models.CharField(verbose_name='Nome', max_length=150)
    descricao = models.TextField(verbose_name='Descrição')
    aprovado = models.BooleanField(verbose_name='Aprovado', default=False)
    atracoes = models.ManyToManyField(Atracao)
    comentarios = models.ManyToManyField(Comentario)
    avaliacoes = models.ManyToManyField(Avaliacao)
    endereco = models.ForeignKey(Endereco, verbose_name='Endereço', on_delete=models.CASCADE, blank=True, null=True)
    foto = models.ImageField(upload_to='pontos_turisticos', null=True, blank=True)

    def __str__(self):
        return self.nome
    
